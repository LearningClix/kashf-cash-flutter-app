import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // splashscreenXdN (209:3986)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // topbarcontenttitledRW (209:3988)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 245.5*fem),
              width: double.infinity,
              height: 101*fem,
              child: Container(
                // statusbariphonekFE (I209:3988;188:4281)
                padding: EdgeInsets.fromLTRB(55.42*fem, 18.34*fem, 32.17*fem, 13.66*fem),
                width: double.infinity,
                height: 54*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // timeqnU (I209:3988;188:4281;6:3949)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 197.08*fem, 0*fem),
                      child: Text(
                        '9:41',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'SF Pro',
                          fontSize: 17*ffem,
                          height: 1.2941176471*ffem/fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                    Container(
                      // levelsMF2 (I209:3988;188:4281;6:3950)
                      margin: EdgeInsets.fromLTRB(0*fem, 4.66*fem, 0*fem, 4.34*fem),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // cellularconnectionU4k (I209:3988;188:4281;6:3956)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.3*fem, 7.5*fem, 0*fem),
                            width: 19.2*fem,
                            height: 12.23*fem,
                            child: Image.asset(
                              'assets/ui-prototype/images/cellular-connection-Ftx.png',
                              width: 19.2*fem,
                              height: 12.23*fem,
                            ),
                          ),
                          Container(
                            // wifia7n (I209:3988;188:4281;6:3955)
                            margin: EdgeInsets.fromLTRB(0*fem, 0.6*fem, 7.16*fem, 0*fem),
                            width: 17.14*fem,
                            height: 12.33*fem,
                            child: Image.asset(
                              'assets/ui-prototype/images/wifi-XTJ.png',
                              width: 17.14*fem,
                              height: 12.33*fem,
                            ),
                          ),
                          Container(
                            // batteryVkY (I209:3988;188:4281;6:3951)
                            width: 27.33*fem,
                            height: 13*fem,
                            child: Image.asset(
                              'assets/ui-prototype/images/battery-Vf2.png',
                              width: 27.33*fem,
                              height: 13*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              // frame37393caG (209:3989)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 334.5*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 158*fem,
                  height: 158*fem,
                  child: Image.asset(
                    'assets/ui-prototype/images/frame-37393-eng.png',
                    width: 158*fem,
                    height: 158*fem,
                  ),
                ),
              ),
            ),
            Container(
              // homeindicatorhbi (I209:3987;2:2955)
              margin: EdgeInsets.fromLTRB(127*fem, 0*fem, 127*fem, 0*fem),
              width: double.infinity,
              height: 5*fem,
              decoration: BoxDecoration (
                borderRadius: BorderRadius.circular(100*fem),
                color: Color(0xff000000),
              ),
            ),
          ],
        ),
      ),
          );
  }
}